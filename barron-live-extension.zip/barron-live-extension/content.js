// Barron.live Plant Status Ticker - Chrome Extension
// From WATERMAXXING.com by Barron Sawyer

(function() {
  'use strict';

  // Check if already injected
  if (document.getElementById('barron-live-ticker-wrapper')) return;

  // Check if user previously closed it this session
  if (sessionStorage.getItem('barron-live-hidden') === 'true') return;

  // Status messages - the full collection from WATERMAXXING
  const statusMessages = [
    // SET 1 - EVERYDAY PLANT CHAOS
    "clarifier #2 skimmer arm tension needs adjustment 🔧",
    "secondary effluent turbidity trending upward 📈",
    "RAS pump #3 seal showing early wear signs 💧",
    "belt filter press polymer dosing slightly high ⚗️",
    "influent flow exceeding design capacity again 🌊",
    "blower #1 bearing temperature elevated 🌡",
    "UV disinfection intensity at 78% — lamp replacement soon 💡",
    "digester gas flare running continuously 🔥",
    "MLSS concentration lower than target 🧫",
    "primary sludge blanket depth at 2.3 feet 📏",
    "aeration basin DO probe needs calibration 📊",
    "chemical storage tank level critical — order placed 🧪",
    "scum pump tripped on overload — again 🔌",
    "permit exceedance avoided by 0.3 mg/L ✅",
    "night shift operator requesting clarification 📞",
    "SCADA system running on hope and good intentions 🖥",
    "lab results pending from samples taken Tuesday 🔬",
    "maintenance backlog currently at 47 items 📋",
    "someone left the sample fridge door open 🚪",
    "headworks grit removal efficiency declining 🪨",
    
    // SET 2 - MORE AUTHENTIC PLANT VIBES
    "chlorine contact tank baffle showing signs of corrosion 🧱",
    "effluent sampler tubing kinked somewhere 🔄",
    "centrifuge vibration alarm cleared itself again 📳",
    "NPDES report due Friday — data still incomplete 📑",
    "overflow weir level sensor drifting 📡",
    "operator found sleeping equipment — not operator 😴",
    "gravity thickener rake speed optimization needed ⚙️",
    "chemical containment area needs pressure washing 🧹",
    "standby generator tested — mostly successful 🔋",
    "flow proportional sampling line clogged 🚰",
    "third shift asking about overtime again 💵",
    "odor complaints from downwind neighbors rising 👃",
    "plant tour scheduled during peak loading hour 🎓",
    "spare parts inventory reveals concerning gaps 📦",
    "regulatory inspector visit announced for next week 👔",
    "process control narrative requires updating 📝",
    "SVI trending in the wrong direction 📉",
    "grease trap truck arrived without appointment 🚛",
    "effluent BOD running close to limit 🎯",
    "someone calibrated the pH probe backwards 🤷",
    "dissolved oxygen controller hunting again 🎯",
    "WAS wasting schedule needs recalculation 🔢",
    "lab QA/QC flags appearing in reports 🚩",
    "membrane integrity test scheduled — prepare excuses 🧤",
    "nutrient removal efficiency below target 🌿",
    "blower VFD displaying cryptic error code 🤖",
    "plant superintendent requesting budget meeting 💼",
    "septage receiving station overwhelmed 🚽",
    "fog monitoring results came back interesting 🌫",
    "emergency shower last inspected questionably ☔",
    
    // SET 3 - MAXIMUM CHAOS WITH RACCOONS
    "blower bearing temperature entering spicy territory 🌡",
    "someone fed the raccoons and now they expect it 🦝",
    "MBR train four offline for reasons 🚂",
    "WAS pump questioning its life choices at 3 AM 🌙",
    "greg's walkie-talkie found in the aeration basin 📻",
    "clarifier scum baffle achieving structural independence 🏗",
    "sample refrigerator now containing someone's lunch 🥪",
    "chemical truck driver asking why we smell like that 🚛",
    "raccoons have established territory in the blower building 🦝",
    "NPDES permit limits feeling more like suggestions 📋",
    "secondary clarifier effluent looking suspiciously chunky 👀",
    "polymer pump stroke length requires interpretive dance 💃",
    "greg locked himself in the control room again 🔐",
    "belt filter press belt tracking toward adventure 🎢",
    "UV transmittance reading hurt SCADA's feelings 💔",
    "sludge hopper level sensor disagreeing with reality 📡",
    "raccoon family relocated from MCC-3 to MCC-4 🦝",
    "someone pressure washed something they shouldn't have 💦",
    "flow meter proving that math is just a suggestion 🔢",
    "RAS chlorination point clogging with regularity 🧱",
    "operator claims the plant makes different sounds at night 👂",
    "EQ basin mixer creating whirlpool of existential doubt 🌀",
    "greg asking if we're sure the raccoons aren't trained 🦝",
    "digester foam reaching escape velocity 🚀",
    "plant HVAC distributing odors democratically 💨",
    "secondary scum pit overflowing into primary concerns 🌊",
    "flow recorder pen running dry mid-violation 🖊",
    "influent BOD testing operator's will to live 🧫",
    "someone connected the wrong chemical to the right pump 🧪",
    "clarifier effluent launder collecting unauthorized birds 🐦",
    "greg proposing raccoon integration into operations 🦝",
    "thickener overflow weir level critical but vague 📏",
    "blower silencer no longer silencing 📢",
    "polymer emulsion breaking before it should 💔",
    "SCADA screen frozen on embarrassing trend line 📊",
    "night shift log reveals concerning timeline gaps ⏰",
    "chemical spill kit last inspected optimistically 🧰",
    "raccoons chewed through another conduit 🦝",
    "centrate pump seal leaking with conviction 💧",
    "greg found talking to the clarifier again 🗣",
    "bar screen rake teeth missing without explanation 🦷",
    "plant dog and raccoons reached uneasy truce 🐕",
    "influent sampler icing over in July somehow ❄️",
    "sludge cake conveyor making choices 🎰",
    "UV system requesting emotional support 💡",
    "someone wrote greg was here on the digester 🖊",
    "flow equalization achieving neither 🌊",
    "chemical room exhaust fan distributing problems 💨",
    "raccoon sighting log now three pages long 🦝",
    "greg suggesting we name the lead raccoon 🏷",
    "lab results confirm the field test was lying 📋",
    "someone cross-threaded the sample tap 🔩",
    "greg requesting hazard pay for basin inspection 💰",
    "scum pump producing sounds from the underworld 👹",
    "membrane bioreactor flux trending toward chaos 📉",
    "chemical containment berm holding but judging 🧱",
    "operator log entry just says never again 📝"
  ];

  const chaosAlerts = [
    "🚨 FLOW ALERT: +30 GPM OVER LIMIT",
    "🚨 TURBIDITY SPIKE: 8.4 NTU",
    "🚨 CLARIFIER TORQUE WARNING",
    "🚨 POLYMER FEED +15%",
    "🚨 BACKWASH PRESSURE SURGE",
    "🚨 CHEMICAL TANK LOW",
    "🚨 INFLUENT PH: 5.2 — CHECK SOURCE",
    "🚨 BLOWER 2 TEMP: 185°F",
    "🚨 RAS FLOW DEVIATION +22%",
    "🚨 SLUDGE BLANKET: 4.8 FT",
    "🚨 DO PROBE DRIFT DETECTED",
    "🚨 UV INTENSITY LOW — CLEAN LAMPS",
    "🚨 SCADA COMM DELAY: 12 SEC",
    "🚨 CHLORINE RESIDUAL: 0.1 MG/L",
    "🚨 EFFLUENT TSS: 28 MG/L",
    "🚨 WET WELL LEVEL: 92%",
    "🚨 DIGESTER GAS PRESSURE HIGH",
    "🚨 BELT PRESS CAKE: 14% SOLIDS"
  ];

  const rareMessages = [
    "night shift stabilized flow at 03:17 ⭐",
    "pump two apologized and resumed operation ⭐",
    "clarifier torque returned to polite levels ⭐",
    "operator claims basin feels calmer tonight ⭐",
    "SCADA and operator reached agreement ⭐",
    "sludge blanket achieved personal best ⭐",
    "pH probe calibrated on first try ⭐",
    "all three clarifiers synchronized perfectly ⭐"
  ];

  function shuffle(array) {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  // Speed settings
  const SPEED_SLOW = 50; // px per second (readable)
  const SPEED_FAST = 75; // 50% faster
  let currentSpeed = SPEED_SLOW;
  let isFast = false;

  function createTicker() {
    // Create wrapper
    const wrapper = document.createElement('div');
    wrapper.id = 'barron-live-ticker-wrapper';

    // Create brand
    const brand = document.createElement('div');
    brand.id = 'barron-live-brand';
    brand.innerHTML = '<span>🕹️ watermaxxing.com</span>';
    brand.title = 'Visit WATERMAXXING.com';
    brand.addEventListener('click', () => {
      window.open('https://watermaxxing.com', '_blank');
    });

    // Create speed toggle button
    const speedBtn = document.createElement('button');
    speedBtn.id = 'barron-live-speed';
    speedBtn.innerHTML = '▶ SLOW';
    speedBtn.title = 'Toggle speed';

    // Create ticker container
    const ticker = document.createElement('div');
    ticker.id = 'barron-live-ticker';

    // Create track
    const track = document.createElement('div');
    track.id = 'barron-live-track';

    // Generate content
    const shuffledStatus = shuffle(statusMessages);
    const shuffledChaos = shuffle(chaosAlerts);

    // 1 in 30 chance for rare message
    const includeRare = Math.random() < (1/30);
    if (includeRare) {
      const rareMsg = rareMessages[Math.floor(Math.random() * rareMessages.length)];
      shuffledStatus.unshift(rareMsg);
    }

    // Interleave: 2 status, 1 chaos
    const combined = [];
    let statusIdx = 0;
    let chaosIdx = 0;

    while (statusIdx < shuffledStatus.length) {
      if (statusIdx < shuffledStatus.length) {
        combined.push({ text: shuffledStatus[statusIdx++], type: 'normal' });
      }
      if (statusIdx < shuffledStatus.length) {
        combined.push({ text: shuffledStatus[statusIdx++], type: 'normal' });
      }
      if (chaosIdx < shuffledChaos.length) {
        combined.push({ text: shuffledChaos[chaosIdx++], type: 'chaos' });
      } else {
        chaosIdx = 0;
        combined.push({ text: shuffledChaos[chaosIdx++], type: 'chaos' });
      }
    }

    // Check for rare messages
    combined.forEach(item => {
      if (item.text.includes('⭐')) {
        item.type = 'rare';
      }
    });

    // Create HTML (triplicate for seamless loop - fixes the reset issue)
    let html = '';
    for (let i = 0; i < 3; i++) {
      combined.forEach(item => {
        html += `<span class="barron-ticker-item ${item.type}">${item.text}</span>`;
      });
    }
    track.innerHTML = html;

    // Create close button
    const closeBtn = document.createElement('button');
    closeBtn.id = 'barron-live-close';
    closeBtn.innerHTML = '×';
    closeBtn.title = 'Hide ticker for this session';
    closeBtn.addEventListener('click', () => {
      wrapper.remove();
      document.documentElement.classList.remove('barron-live-active');
      sessionStorage.setItem('barron-live-hidden', 'true');
    });

    // Assemble
    ticker.appendChild(track);
    wrapper.appendChild(brand);
    wrapper.appendChild(speedBtn);
    wrapper.appendChild(ticker);
    wrapper.appendChild(closeBtn);

    // Insert into page
    document.documentElement.classList.add('barron-live-active');
    document.body.insertBefore(wrapper, document.body.firstChild);

    // Function to set animation duration
    function setSpeed(speed) {
      const trackWidth = track.scrollWidth;
      // We scroll 33.333% of the track (one set of messages out of 3)
      const scrollDistance = trackWidth / 3;
      const duration = scrollDistance / speed;
      track.style.setProperty('--ticker-duration', `${duration}s`);
      console.log(`[WATERMAXXING] Track width: ${trackWidth}px, Scroll distance: ${scrollDistance}px, Duration: ${duration}s at ${speed}px/s`);
    }

    // Calculate initial animation duration - use setTimeout to ensure DOM is fully rendered
    setTimeout(() => {
      requestAnimationFrame(() => {
        setSpeed(currentSpeed);
      });
    }, 100);

    // Speed toggle handler
    speedBtn.addEventListener('click', () => {
      isFast = !isFast;
      currentSpeed = isFast ? SPEED_FAST : SPEED_SLOW;
      speedBtn.innerHTML = isFast ? '▶▶ FAST' : '▶ SLOW';
      speedBtn.classList.toggle('fast', isFast);
      
      // Smoothly update speed
      requestAnimationFrame(() => {
        setSpeed(currentSpeed);
      });
    });

    // Glitch effect every 10 seconds
    setInterval(() => {
      brand.classList.add('glitch');
      setTimeout(() => {
        brand.classList.remove('glitch');
      }, 300);
    }, 10000);

    // Pause when tab not visible
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        track.classList.add('paused');
      } else {
        track.classList.remove('paused');
      }
    });
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createTicker);
  } else {
    createTicker();
  }

})();
