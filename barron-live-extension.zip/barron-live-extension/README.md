# Barron.live - Plant Status Ticker

A Chrome extension that displays a humorous water treatment plant status ticker at the top of every webpage. Created by Barron Sawyer, from [WATERMAXXING.com](https://watermaxxing.com).

## Features

- 🌊 100+ rotating plant status messages
- 🚨 Random chaos alerts (turbidity spikes, flow alerts, etc.)
- 🦝 Occasional raccoon sightings
- ⭐ Rare positive messages (1 in 30 chance)
- 🎨 Synthwave aesthetic matching WATERMAXXING.com
- ❌ Close button to hide for the session

---

## INSTALLATION (No Chrome Web Store Required)

### For Personal Use:

1. **Download and unzip** the `barron-live-extension.zip` file
2. Open Chrome and go to: `chrome://extensions/`
3. Enable **"Developer mode"** (toggle in top-right corner)
4. Click **"Load unpacked"**
5. Select the unzipped `barron-live-extension` folder
6. Done! The ticker will appear on all websites

### To Update:
1. Make changes to the files
2. Go to `chrome://extensions/`
3. Click the refresh icon on the Barron.live extension card

---

## SHARING WITH OTHERS (No Store Required)

### Method 1: Share the ZIP File (Easiest)

1. Send them the `barron-live-extension.zip` file via:
   - Email attachment
   - Google Drive / Dropbox link
   - Slack / Discord
   - AirDrop

2. They follow the same installation steps above

**Note:** Chrome will show a warning about "developer mode extensions" — this is normal for extensions not from the store. They just need to click "Keep" or dismiss the warning.

### Method 2: Share via GitHub (More Professional)

1. Create a GitHub repository (e.g., `barron-live-ticker`)
2. Upload all the extension files
3. Share the repo link
4. Others can:
   - Download as ZIP, or
   - `git clone` the repo
   - Then load as unpacked extension

### Method 3: Host the ZIP on Your Website

1. Upload `barron-live-extension.zip` to watermaxxing.com
2. Create a download page with instructions
3. Share the link: `https://watermaxxing.com/barron-live`

---

## CHROME WEB STORE (Optional)

Publishing to the Chrome Web Store is **NOT required** for sharing with friends/colleagues, but if you want wider distribution:

### Requirements:
- One-time $5 developer registration fee
- Google account
- Privacy policy (can be simple for free extensions)
- Screenshots and promotional images

### Process:
1. Go to: https://chrome.google.com/webstore/devconsole/
2. Pay $5 registration fee
3. Create a new item
4. Upload the ZIP file
5. Fill in listing details (description, screenshots, etc.)
6. Submit for review (usually 1-3 business days)

### Pros of Store Publishing:
- Automatic updates for users
- No "developer mode" warnings
- Discoverable by search
- Download stats

### Cons:
- $5 fee
- Review process (could be rejected)
- Need privacy policy
- More bureaucracy

---

## FILE STRUCTURE

```
barron-live-extension/
├── manifest.json      # Extension configuration
├── content.js         # Main ticker logic
├── ticker.css         # Styling
├── icons/
│   ├── icon16.png
│   ├── icon32.png
│   ├── icon48.png
│   └── icon128.png
└── README.md          # This file
```

---

## CUSTOMIZATION

### Add/Edit Messages:
Edit `content.js` and modify these arrays:
- `statusMessages` — Regular plant status updates
- `chaosAlerts` — Red alert messages
- `rareMessages` — Gold star positive messages

### Change Colors:
Edit `ticker.css` to adjust the synthwave color scheme.

### Change Speed:
In `content.js`, find the duration calculation and adjust:
```javascript
const duration = (trackWidth / 2) / 60; // 60px per second
```

---

## TROUBLESHOOTING

**Ticker not appearing:**
- Make sure Developer Mode is enabled
- Try refreshing the extension in `chrome://extensions/`
- Check if the site has strict CSP (some sites block extensions)

**"Developer mode extensions" warning:**
- This is normal for unpacked extensions
- Click "Dismiss" or it will auto-hide
- The extension still works fine

---

## LICENSE

Free to use, share, and modify. Created by Barron Sawyer.

Visit [WATERMAXXING.com](https://watermaxxing.com) for more water treatment content.
